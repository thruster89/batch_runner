import threading

stop_event = threading.Event()