# file: v2/adapters/sources/vertica_source.py

import csv
import gzip
import time
from pathlib import Path


def export_sql_to_csv(
    conn,
    sql_text,
    out_file,
    logger,
    compression="none",
    fetch_size=10000,
    stall_seconds=1800,   # 30분 기본 stall 기준
):
    cursor = conn.cursor()
    cursor.execute(sql_text)

    if cursor.description is None:
        logger.warning("No result set returned, skipping CSV export")
        cursor.close()
        return 0

    columns = [col[0] for col in cursor.description]

    out_file = Path(out_file)
    tmp_file = out_file.with_suffix(out_file.suffix + ".tmp")
    out_file.parent.mkdir(parents=True, exist_ok=True)

    total_rows = 0
    last_progress = time.time()
    last_heartbeat = time.time()

    try:
        if compression == "gzip":
            f = gzip.open(tmp_file, "wt", newline="", encoding="utf-8")
        else:
            f = open(tmp_file, "w", newline="", encoding="utf-8")

        with f:
            writer = csv.writer(f)
            writer.writerow(columns)

            while True:
                rows = cursor.fetchmany(fetch_size)

                now = time.time()

                # stall 감지
                if not rows:
                    # 결과 종료
                    break

                writer.writerows(rows)
                total_rows += len(rows)
                last_progress = now

                # 기존 progress 로그
                if total_rows % (fetch_size * 5) == 0:
                    logger.info("CSV progress: %d rows", total_rows)
                    last_heartbeat = now
                else:
                    # heartbeat (2분마다)
                    if now - last_heartbeat >= 120:
                        logger.info("CSV progress: %d rows (heartbeat)", total_rows)
                        last_heartbeat = now

                # stall watchdog
                if now - last_progress > stall_seconds:
                    raise RuntimeError(
                        f"Fetch stalled > {stall_seconds} seconds"
                    )

        tmp_file.replace(out_file)
        logger.debug("File committed: %s", out_file)
        cursor.close()

        logger.info(
            "CSV export completed | rows=%d file=%s",
            total_rows,
            out_file,
        )

    except Exception:
        if tmp_file.exists():
            tmp_file.unlink()
        raise

    return total_rows
